const Header = () => (
    <header className="bg-blue-500 text-white text-center py-4">
      <h1 className="text-2xl">Demo Automation Site</h1>
    </header>
  );
  
  export default Header;
  