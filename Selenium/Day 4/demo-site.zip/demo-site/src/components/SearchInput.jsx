const SearchInput = () => (
    <input
      type="text"
      id="search-box"
      placeholder="Search here..."
      className="border p-2 w-full"
    />
  );
  
  export default SearchInput;
  