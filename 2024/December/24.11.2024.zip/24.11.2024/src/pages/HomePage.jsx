const HomePage = () => {
  return (
    <>
      <h1>This is Home Page </h1>
      <p>some text here</p>
    </>
  );
};

export default HomePage