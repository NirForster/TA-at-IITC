import React from 'react';

const AboutPage = () => {
    return (
        <div>
            <h1>About Us</h1>
            <p>Welcome to our website. Here you can find more information about us.</p>
        </div>
    );
};

export default AboutPage;