const NotFound = () => {
  return (
    <>
      <h1>404</h1>
      <p>This page doesnt exists</p>
    </>
  );
};

export default NotFound